var root = document.getElementById('root');
const App = (props) => {
    React.createElement(inputs,null,)
};

ReactDom.Render(React.createElement(App), root);
